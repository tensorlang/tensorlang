# -*- coding: utf-8 -*-

__author__ = 'Boris FELD'
__email__ = 'boris@sqreen.io'
__version__ = '0.1.7-dev'

__all__ = ['py_mini_racer']
