"""A Tornado based event loop for PyZMQ."""

from zmq.eventloop.ioloop import IOLoop

__all__ = ['IOLoop']